[CmdletBinding()]
param (
    [Parameter(Mandatory = $true)]
    [String] $TemplateFolderPath,

    [Parameter(Mandatory = $true)]
    [String] $TestsDisplayName,

    [Parameter(Mandatory = $true)]
    [String] $ResourceGroupName
)

BeforeAll {
    $templateFile = Join-Path -ChildPath "azuredeploy.json" -Path $TemplateFolderPath
    $templateFileObject = Get-Content -Path $templateFile -Raw | ConvertFrom-Json
    $templateFileElements = $templateFileObject.PSObject.Properties.Name
    $templateFileParameters = $templateFileObject.parameters
    $templateFileParameterNames = $templateFileParameters.PSObject.Properties.Name

    $templateParameterFile = Join-Path -ChildPath "azuredeploy.parameters.json" -Path $TemplateFolderPath
    $templateParameterFileObject = Get-Content -Path $templateParameterFile -Raw | ConvertFrom-Json
    $templateParameterFileElements = $templateParameterFileObject.PSObject.Properties.Name
    $templateParameterFileParameterNames = $templateParameterFileObject.parameters.PSObject.Properties.Name
}

Describe "Coding standards" {
    Context "ARM template file" {
        It "[<TestsDisplayName>] Should not have an empty azuredeploy.json file" {
            $templateFileObject | Should -Not -BeNullOrEmpty
        }

        It "[<TestsDisplayName>] Should be deployable to a Resource Group" {
            if ($TemplateFolderPath.Contains("/pre-prod/")) {
                $templateDeployment = Test-AzResourceGroupDeployment `
                    -ResourceGroupName $ResourceGroupName `
                    -TemplateFile $templateFile `
                    -TemplateParameterFile $templateParameterFile `
                    -Mode Complete

                $templateDeployment | Should -BeNullOrEmpty
            }
        }

        It "[<TestsDisplayName>] Should contain mandatory elements" {
            foreach ($mandatoryElement in '$schema', "contentVersion", "parameters", "resources") {
                $templateFileElements | Should -Contain $mandatoryElement
            }
        }

        It "[<TestsDisplayName>] Should have elements in the correct order" {
            "$templateFileElements" | Should -MatchExactly '^\$schema contentVersion parameters(| variables)(| functions) resources(| outputs)$'
        }

        It "[<TestsDisplayName>] Should have a correct content version" {
            $templateFileObject.contentVersion | Should -MatchExactly "^[\d]+.[\d]+.[\d]+.0$"
        }

        It "[<TestsDisplayName>] Should use camel case for parameter names" {
            foreach ($templateFileParameterName in $templateFileParameterNames) {
                $templateFileParameterName | Should -MatchExactly "^[^A-Z].*$"
            }
        }

        It "[<TestsDisplayName>] Should not have API version parameter" {
            $templateFileParameterNames | Should -Not -Contain "apiVersion"
        }

        It "[<TestsDisplayName>] Should have location parameter" {
            if ($templateFileObject.resources | Where-Object -FilterScript { $_.type -match "^[a-zA-Z]+\.[a-zA-Z]+/[a-zA-Z]+$" }) {
                $templateFileParameterNames | Should -Contain "location"
            }
        }

        It "[<TestsDisplayName>] Should have resourceGroup().location as default value for location parameter" {
            if ($templateFileObject.resources | Where-Object -FilterScript { $_.type -match "^[a-zA-Z]+\.[a-zA-Z]+/[a-zA-Z]+$" }) {
                $templateFileParameterNames | Should -Contain "location" -ErrorAction Stop
                $templateFileParameters.location.PSObject.Properties.Name | Should -Contain "defaultValue" -ErrorAction Stop
                $templateFileParameters.location.defaultValue | Should -BeExactly "[resourceGroup().location]"
            }
        }

        It "[<TestsDisplayName>] Should not have allowed values for location parameter" {
            if ($templateFileObject.resources | Where-Object -FilterScript { $_.type -match "^[a-zA-Z]+\.[a-zA-Z]+/[a-zA-Z]+$" }) {
                $templateFileParameterNames | Should -Contain "location" -ErrorAction Stop
                $templateFileParameters.location.PSObject.Properties.Name | Should -Not -Contain "allowedValues"
            }
        }

        It "[<TestsDisplayName>] Should not use empty strings for default value" {
            foreach ($templateFileParameterName in $templateFileParameterNames) {
                if ($templateFileParameters.$templateFileParameterName.PSObject.Properties.Name.Contains("defaultValue")) {
                    $templateFileParameters.$templateFileParameterName.defaultValue | Should -Not -BeNullOrEmpty
                    $templateFileParameters.$templateFileParameterName.defaultValue | Should -Not -Be "null"
                    $templateFileParameters.$templateFileParameterName.defaultValue | Should -Not -Be "[json('null')]"
                }
            }
        }

        It "[<TestsDisplayName>] Should not use empty strings for allowed values" {
            foreach ($templateFileParameterName in $templateFileParameterNames) {
                if ($templateFileParameters.$templateFileParameterName.PSObject.Properties.Name.Contains("allowedValues")) {
                    $templateFileParameters.$templateFileParameterName.allowedValues | ForEach-Object -Process {
                        $_ | Should -Not -BeNullOrEmpty
                        $_ | Should -Not -Be "null"
                        $_ | Should -Not -Be "[json('null')]"
                    }
                }
            }
        }

        It "[<TestsDisplayName>] Should have parameter descriptions" {
            foreach ($templateFileParameterName in $templateFileParameterNames) {
                $templateFileParameters.$templateFileParameterName.PSObject.Properties.Name.Contains("metadata") | Should -BeTrue -ErrorAction Stop
                $templateFileParameters.$templateFileParameterName.metadata.PSObject.Properties.Name.Contains("description") | Should -BeTrue -ErrorAction Stop
                $templateFileParameters.$templateFileParameterName.metadata.description | Should -Not -BeNullOrEmpty
            }
        }

        It "[<TestsDisplayName>] Should end parameter descriptions with a period" {
            foreach ($templateFileParameterName in $templateFileParameterNames) {
                $templateFileParameters.$templateFileParameterName.PSObject.Properties.Name.Contains("metadata") | Should -BeTrue -ErrorAction Stop
                $templateFileParameters.$templateFileParameterName.metadata.PSObject.Properties.Name.Contains("description") | Should -BeTrue -ErrorAction Stop
                $templateFileParameters.$templateFileParameterName.metadata.description | Should -Match "\.$"
            }
        }

        It "[<TestsDisplayName>] Should not have API version variable" {
            if ($templateFileElements -contains "variables") {
                $templateFileObject.variables.PSObject.Properties.Name | Should -Not -Contain "apiVersion"
            }
        }

        It "[<TestsDisplayName>] Should have resource elements in the correct order" {
            foreach ($resource in $templateFileObject.resources) {
                "$($resource.PSObject.Properties.Name)" | Should -MatchExactly "^(|comment )(|condition )(|scope )type apiVersion name(| location)(| zones)(| sku)(| kind)(| scale)(| plan)(| identity)(| copy)(| dependsOn)(| tags)(| properties)(| resources)$"
            }
        }

        It "[<TestsDisplayName>] Should not contain the word secret in outputs" {
            if ($templateFileElements -contains "outputs") {
                foreach ($outputName in $templateFileObject.outputs.PSObject.Properties.Name) {
                    $outputName | Should -Not -BeLike "*secret*"
                }
            }
        }
    }

    Context "ARM template parameter file" {
        It "[<TestsDisplayName>] Should contain mandatory elements" {
            foreach ($mandatoryElement in '$schema', "contentVersion", "parameters") {
                $templateParameterFileElements | Should -Contain $mandatoryElement
            }
        }

        It "[<TestsDisplayName>] Should have elements in the correct order" {
            "$templateParameterFileElements" | Should -MatchExactly '^\$schema contentVersion parameters$'
        }

        It "[<TestsDisplayName>] Should have a correct content version" {
            $templateParameterFileObject.contentVersion | Should -MatchExactly "^[\d]+.[\d]+.[\d]+.0$"
        }

        It "[<TestsDisplayName>] Should use camel case for parameter names" {
            foreach ($templateParameterFileParameterName in $templateParameterFileParameterNames) {
                $templateParameterFileParameterName | Should -MatchExactly "^[^A-Z].*$"
            }
        }

        It "[<TestsDisplayName>] Should not have API version as a parameter" {
            $templateParameterFileParameterNames | Should -Not -Contain "apiVersion"
        }
    }
}
