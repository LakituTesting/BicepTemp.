﻿[CmdletBinding()]
param (
    [Parameter(Mandatory = $true)]
    [String] $ResourceGroupName
)

Install-Module -Name Pester -Force -SkipPublisherCheck -AllowClobber
Install-Module -Name Az.Resources -Force -SkipPublisherCheck -AllowClobber
Import-Module -Name Az.Resources -Cmdlet Test-AzResourceGroupDeployment -Force

function Get-TemplateFolderPath {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [String] $RepoRootPath
    )

    return Get-ChildItem -Include "*.json" -Path $RepoRootPath -Recurse |
        Where-Object -FilterScript { (Get-Content -Path $_) -cmatch "/deploymentTemplate.json#" -and $_ -cnotmatch "management\\microsoft.compute"} |
        Split-Path -Parent
}

function New-TestsDisplayName {
    [CmdletBinding()]
    [OutputType([String])]
    param (
        [Parameter(Mandatory = $true)]
        [String] $TemplateFolderPath
    )

    $resourceTypeName = Split-Path -Path (Split-Path -Path $TemplateFolderPath -Parent) -Leaf
    $severityLevel = Split-Path -Path $TemplateFolderPath -Leaf

    return "$resourceTypeName - $severityLevel"
}

$repoRootPath = Split-Path -Path $PSScriptRoot -Parent

$pesterResults = @()

$pesterContainer = New-PesterContainer `
    -Path "$repoRootPath\tests\CodingStandards.Folder.Naming.Tests.ps1" `
    -Data @{ RepoRootPath = $repoRootPath }

$pesterResults += Invoke-Pester -Container $pesterContainer -Output Detailed -PassThru

foreach ($templateFolderPath in (Get-TemplateFolderPath -RepoRootPath "$repoRootPath\resourcegroup-deployments")) {
    Write-Host "Testing '$templateFolderPath'."
    $testsDisplayName = New-TestsDisplayName -TemplateFolderPath $templateFolderPath

    $pesterContainer = New-PesterContainer `
        -Path "$repoRootPath\tests\CodingStandards.File.Naming.Tests.ps1" `
        -Data @{ TemplateFolderPath = $templateFolderPath; TestsDisplayName = $testsDisplayName }

    $pesterResults += Invoke-Pester -Container $pesterContainer -Output Detailed -PassThru

    $pesterContainer = New-PesterContainer `
        -Path "$repoRootPath\tests\CodingStandards.Template.Tests.ps1" `
        -Data @{ TemplateFolderPath = $templateFolderPath; TestsDisplayName = $testsDisplayName; ResourceGroupName = $ResourceGroupName }

    $pesterResults += Invoke-Pester -Container $pesterContainer -Output Detailed -PassThru

    $pesterContainer = New-PesterContainer -Path "$templateFolderPath\tests\*.Tests.ps1"

    $pesterResults += Invoke-Pester -Container $pesterContainer -Output Detailed -PassThru
}

$errors = 0

foreach ($pesterResult in $pesterResults) {
    foreach ($failedPesterContainer in ($pesterResult.Containers | Where-Object -FilterScript { $_.FailedCount })) {
        Write-Host "Pester test '$(Split-Path -Path $failedPesterContainer.Item -Leaf)' had $($failedPesterContainer.FailedCount) failed test(s)."
    }

    foreach ($failedPesterTest in $pesterResult.Failed) {
        Write-Host "##vso[task.logissue type=error]$($failedPesterTest.Name)"
        $errors++
    }
}

if ($errors) {
    [Environment]::Exit(1)
}
