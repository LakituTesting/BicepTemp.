[CmdletBinding()]
param (
    [Parameter(Mandatory = $true)]
    [String] $RepoRootPath
)

BeforeAll {
    $templateFolderPaths = (Get-ChildItem -File -Include "azuredeploy.json" -Path $RepoRootPath -Recurse | Where-Object -FilterScript { $_ -cnotmatch "\\management\\" }).Directory.FullName
}

Describe "Coding standards" {
    Context "Folder naming conventions" {
        It "Should have valid subfolders under repo root path" {
            Get-ChildItem -Directory -Path $RepoRootPath |
                Where-Object -FilterScript { $_.Name -notin "management", "pipelines", "resourcegroup-deployments", "scripts", "subscription-deployments", "tests" } |
                Should -BeNullOrEmpty
        }

        It "Should have folder names in lowercase" {
            Get-ChildItem -Directory -Path $RepoRootPath -Recurse |
                Where-Object -FilterScript { $_.FullName -notlike "*\management\*"} |
                Where-Object -FilterScript { $_.Name -cmatch "[A-Z]" } |
                Should -BeNullOrEmpty
        }

        It "Should have template folders following the resource-type naming pattern" {
            $templateFolderPaths |
                Split-Path -Parent |
                Select-Object -Unique |
                Where-Object -FilterScript { (Split-Path -Path $_ -Leaf) -cnotmatch "^(?!.*--)[a-z][a-z-]*(?<!-)$" } |
                Should -BeNullOrEmpty
        }

        It "Should have template files in critical and non-critical folders or prod and pre-prod folders" {
            $templateFolderPaths |
                Where-Object -FilterScript { (Split-Path -Path $_ -Leaf) -notin "critical", "non-critical", "prod", "pre-prod" } |
                Should -BeNullOrEmpty
        }
    }
}
