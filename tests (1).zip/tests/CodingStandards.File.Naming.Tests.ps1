[CmdletBinding()]
param (
    [Parameter(Mandatory = $true)]
    [String] $TemplateFolderPath,

    [Parameter(Mandatory = $true)]
    [String] $TestsDisplayName
)

BeforeAll {
    $templateFolderFiles = Get-ChildItem -File -Path $TemplateFolderPath
}

Describe "Coding standards" {
    Context "File naming conventions" {
        It "[<TestsDisplayName>] Should contain mandatory files" {
            "azuredeploy.json", "azuredeploy.parameters.json", "README.md" |
                Where-Object -FilterScript { $templateFolderFiles.Name -notcontains $_ } |
                Should -BeNullOrEmpty
        }

        It "[<TestsDisplayName>] Should have a template file named azuredeploy.json" {
            $templateFolderFiles |
                Where-Object -FilterScript { $_.Name -match "^azuredeploy.json$" -and $_.Name -cnotmatch "[a-z]" } |
                Should -BeNullOrEmpty
        }

        It "[<TestsDisplayName>] Should have a template parameter file named azuredeploy.parameters.json" {
            $templateFolderFiles |
                Where-Object -FilterScript { $_.Name -match "^azuredeploy.parameters.json$" -and $_.Name -cnotmatch "[a-z]" } |
                Should -BeNullOrEmpty
        }

        It "[<TestsDisplayName>] Should have a README file named README.md" {
            $templateFolderFiles |
                Where-Object -FilterScript { $_.Name -match "^README.md$" -and $_.Name -cnotmatch "README.md" } |
                Should -BeNullOrEmpty
        }

        It "[<TestsDisplayName>] Should optionally have a Bicep file named main.bicep" {
            $templateFolderFiles |
                Where-Object -FilterScript { $_.Extension -eq ".bicep" -and $_.Name -cnotmatch "main.bicep" } |
                Should -BeNullOrEmpty
        }
    }
}
